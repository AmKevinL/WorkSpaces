# Security Policy

Security is super important to me. So please don't hesitate to bring to my attention any issues you see.
