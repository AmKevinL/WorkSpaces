## Open a GitHub plugin repository (This is way more cool than it sounds)
The command palette contains a command **BRAT: Open the GitHub repository for a plugin**. This gives you a list of all beta plugins registered with BRAT, but also all plugins from the community plugin list. By selecting a plugin from the list, the GitHub repository will be opened in your browser

<a href="https://twitter.com/TfTHacker/status/1452175686928580612" target="_blank"><img style="width:200px;" src="https://raw.githubusercontent.com/TfTHacker/obsidian42-brat/main/help/GithubOpenrepositories.png"></a> Click image for video demo!


## Open a GitHub themes repository
Similiar to the _Open a GitHub pluugin repository_ command, the Open a Github theme repository will open  a github repository for a theme published in the community theme list.