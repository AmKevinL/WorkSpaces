
## Logging Support
In settings, Logging can be enabled. This logs information about updates to plugins into a log file. This is useful for you to keep a history of what BRAT has updated. 

The log is saved to your vault. The log file path can be customized in settings.
