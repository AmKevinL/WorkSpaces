---
name: API bug report
about: 'For reproducible bugs with the API only. If you have a question, you should
  instead go to our discord server under the #plugin-dev channel to ask for help.'
title: 'Bug: '

---

**Steps to reproduce:**
-
