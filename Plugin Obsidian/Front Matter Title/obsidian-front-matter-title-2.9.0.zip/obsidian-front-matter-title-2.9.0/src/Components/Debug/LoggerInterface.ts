export default interface LoggerInterface {
    log(...value: any[]): void;
}
