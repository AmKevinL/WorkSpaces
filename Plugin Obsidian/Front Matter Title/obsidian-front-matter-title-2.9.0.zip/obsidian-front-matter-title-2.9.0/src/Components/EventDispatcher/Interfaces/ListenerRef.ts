export default interface ListenerRef<T> {
    getName(): T;
}
