export default class PathNotFoundException extends Error {}
