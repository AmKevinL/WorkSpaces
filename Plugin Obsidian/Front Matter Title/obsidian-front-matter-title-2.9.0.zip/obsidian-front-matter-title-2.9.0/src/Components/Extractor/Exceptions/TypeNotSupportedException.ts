export default class TypeNotSupportedException extends Error {}
