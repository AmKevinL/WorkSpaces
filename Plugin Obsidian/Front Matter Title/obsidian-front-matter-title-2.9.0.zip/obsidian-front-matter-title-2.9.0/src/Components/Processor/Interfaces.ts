export default interface ProcessorInterface {
    process(value: string): string;
}
