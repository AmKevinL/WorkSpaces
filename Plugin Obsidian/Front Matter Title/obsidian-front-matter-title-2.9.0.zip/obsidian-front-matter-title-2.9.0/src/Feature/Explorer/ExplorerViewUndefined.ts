export default class ExplorerViewUndefined extends Error {}
