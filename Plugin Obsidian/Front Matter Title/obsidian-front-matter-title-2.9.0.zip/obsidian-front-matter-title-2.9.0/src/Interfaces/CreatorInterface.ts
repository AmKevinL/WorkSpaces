export default interface CreatorInterface {
    create(path: string): string | null;
}
