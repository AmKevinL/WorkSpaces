export default interface FilterInterface {
    check(path: string): boolean;
}
