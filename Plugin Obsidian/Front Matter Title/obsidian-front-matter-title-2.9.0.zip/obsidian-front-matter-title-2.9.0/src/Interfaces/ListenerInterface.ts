export default interface ListenerInterface {
    bind(): void;
    unbind(): void;
}
